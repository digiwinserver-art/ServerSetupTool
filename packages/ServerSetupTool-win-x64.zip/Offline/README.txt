﻿在有網路的電腦執行 EXE，按「製作離線安裝包」，勾選需要的安裝檔並下載到本資料夾。
7-Zip：7zip_installer.exe
鼎新服務雲管家：SCP.Desktop.Setup.exe
IIS Crypto CLI：IISCryptoCli.exe
Chrome x64 MSI：googlechromestandaloneenterprise64.msi
.NET 3.5：另選取符合目標 Windows 版本、build 與 x64 架構的 sources/sxs 匯入，存為 sxs-* 資料夾。IIS 可能另需完整媒體。
製作後將 EXE、exe.config 與整個 Offline 一起複製到離線電腦；如有自訂 Config.json 亦須複製。
目標電腦需 .NET Framework 4.8。執行工具、勾選「僅使用離線檔案」，再選取工作安裝；.NET 3.5 選擇此處的 sxs-* 位置。
本發布包不預先附帶第三方安裝檔。詳見上一層 README.md 或使用說明.html。