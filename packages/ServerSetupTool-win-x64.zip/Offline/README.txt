Place official x64 installers here. See README.md for exact filenames. No third-party installers are bundled.
