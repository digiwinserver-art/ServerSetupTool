﻿# ServerSetupTool 1.0.32

Windows Server 2016／2019／2022／2025 Desktop Experience 與 Windows 11 以上 x64 新機設定工具。主程式以 C#／WinForms 開發，目標 .NET Framework 4.8。成品不需要 .NET 10、Python、PowerShell 7 或 Visual Studio。

## 系統相容性

- 主程式目標維持 **.NET Framework 4.8**，不升級目標版本。Server 2016／2019 若尚未安裝 4.8，請先安裝 [Microsoft .NET Framework 4.8 Runtime](https://dotnet.microsoft.com/en-us/download/dotnet-framework/net48)；Windows 11 已有 4.8／4.8.1 時不需降版。
- Windows 11 家用版無遠端桌面主機功能，該項目停用；其他版本會檢查 EditionID。
- IIS Crypto 僅在 Windows Server 2019／2022／2025 提供。Windows Server 2016 因應用程式相容性停用此項，Windows 用戶端也不提供。
- .NET 3.5 光碟安裝適用於 Server 2016／2019／2022／2025、Windows 11 至 25H2。核對 x64、Server／用戶端類型及作業系統 build；無相符光碟時，可選擇連網安裝、選擇 sxs 位置或取消 .NET 3.5 與 IIS。僅使用離線檔案模式下仍可選擇 sxs，連網按鈕停用。
- Windows 11 26H1（build 28000）以上已改用 .NET 3.5 獨立安裝程式，因此停用本工具的光碟快速安裝與依賴 Windows NetFx3 元件的 IIS 方案。
- Windows 11 以上用戶端依 build 下限允許啟動；尚未發行版本及第三方安裝器不能保證所有功能均可用。各項仍需通過實際狀態檢查。

## 使用方式

1. 解壓縮發佈 ZIP，執行 ServerSetupTool.exe，接受正常的管理員 UAC 提升提示。
2. 等候初次唯讀掃描。可切換正體中文、簡體中文或英文。若 Windows 的某項狀態提供者沒有回應，程式會隔離重查；無法完成的項目顯示「無法確認」，不會預設勾選。詳情保存在 `C:\伺服器設定工具\LOG` 的報告中。若連基本環境資訊也無法取得，錯誤會寫入 `inspection-errors.log`。
3. PING、共用及 RDP 保留各規則現有來源範圍；如需調整，使用「開啟Windows進階防火牆」。
4. 勾選要執行的工作，按「執行所選項目」。
5. 查看結果、人工處理及重新啟動需求。程式不自動重新啟動。
6. 執行完成後查看結果視窗；紀錄會自動保存在 C:\伺服器設定工具\LOG。

初次檢查後，預設勾選尚未完成的 PING、RDP、7-Zip、鼎新及 IIS Crypto；已符合／已安裝項目不勾選。工作項目左側表頭的全選勾選框包含完全停用 UAC、密碼複雜度等工作，執行前請按實際需求選擇。

主畫面與快速防火牆表格可按住左鍵上下拖曳捲動；拖曳不會勾選工作，點方塊才切換。主畫面下方紀錄縮為兩行，按「展開紀錄」查看完整、持續更新的內容。

## 十二項工作

- PING：IPv4／IPv6 Echo Request，三種防火牆設定檔。
- 檔案與印表機共用：三種設定檔；不建立共用，不啟用 SMB1。PING 規則獨立管理。
- RDP：啟用連線、NLA 與 TCP／UDP 3389 規則；自訂 RDP 埠明確標示需人工處理，不改回預設埠。
- 7-Zip：執行時查詢官方最新版 x64，靜默安裝並核對已安裝版本。
- 鼎新服務雲管家：以 C:\DigiwinSCP\SCP\Runtime\SCP.Desktop.Shell.exe 是否存在判定已安裝；未安裝時下載並開啟互動安裝精靈，隨即繼續其他工作，不等待視窗關閉。結果標示需自行完成安裝，完成後可按「僅檢查狀態」。
- IIS Crypto：核對 CLI 說明，備份相關登錄資料及官方 REG 備份，再套用 Best Practices。逐項比對官方 4.0.18.0 Best Practices 的版本對應登錄設定（Server 2019：51 項；2022／2025：57 項）；已符合時略過，套用後再次驗證並提示重新啟動。雙擊工作列可查看不符合的項目。
- UAC：完全停用 EnableLUA。已停用時提示「如果沒有生效，請重新開機」。
- 自動登入：將 DevicePasswordLessBuildVersion 設為 DWORD 0，完成後點擊狀態／結果中的 netplwiz 連結，手動設定登入帳號。AD 環境可用下方按鈕前往 Microsoft Autologon 官方網站。
- Chrome：預設不勾選；使用 Google 官方 x64 MSI 靜默安裝。偵測到電腦或使用者已安裝 Chrome 時直接略過，不重裝、不更新。
- .NET Framework 3.5：預設不勾選；先用相容光碟安裝，無相容光碟可選擇連網、指定 sxs 資料夾或取消。
- IIS：預設不勾選，方案預設「基本」。勾選時一併選取 .NET 3.5，必須完成 .NET 3.5 才安裝 IIS。需要重開機時先暫停 IIS，不自動重新開機。詳見下方方案表。
- 密碼複雜度：僅未加入 AD 且具備本機安全性設定元件的電腦；只調整 PasswordComplexity，不改密碼長度、期限或鎖定。

AD 成員可使用 Autologon，但可能受登入原則限制；網域控制站停用自動登入與密碼複雜度工作。Windows 10 及更早版本、Server Core 或未支援的 Server build 僅提供唯讀檢查，無強制繞過按鈕。

## 服務用本機帳號

「開啟網卡設定」右側新增「新增服務用本機帳號」。視窗上方說明用途，左側顯示本機帳號及登入畫面隱藏狀態，右側輸入帳號、密碼與確認密碼；可切換顯示兩個密碼欄位。

勾選即在登入帳號清單中隱藏，取消勾選移除隱藏設定，立即套用並重新核對。Administrator、Guest、DefaultAccount、WDAGUtilityAccount 不顯示且禁止修改；依 RID 500／501／503／504 辨識，改名後仍受保護。隱藏不等於禁止登入，也不變更帳號啟用狀態；其他登入原則仍適用。

新帳號先以停用狀態建立，加入一般 Users 群組、設定隱藏並確認後才啟用；不加入 Administrators 或 Remote Desktop Users，不授予服務登入權限，也不更改密碼到期或系統密碼原則。Windows 回報密碼複雜度或帳號建立錯誤時，直接顯示原始訊息及錯誤碼。密碼不寫入命令列、設定或日誌。

後續設定失敗會保留新帳號並嘗試確保停用，顯示實際結果供 Windows 帳號管理工具處理，不自動刪除帳號。網域控制站不提供此功能。成功後顯示建立完成訊息；其他設定請使用標準 Windows 帳號管理流程。

## 快速設定防火牆

下方「快速設定防火牆」位於「開啟Windows進階防火牆」右側、「開啟網卡設定」左側。開啟獨立視窗，依指定順序列出 14 種服務，不支援排序或自行改寫 PORT。

所有服務採 TCP 連入，套用網域／私人／公用，來源為任何位址。連接埠清單依使用者提供的 2026 年 9 月設定，EAI 已確認為 9990-9999、20393-20399。版本更新後請依實際產品需要確認。

初次無規則時不勾選；每次開啟會讀取 Windows 防火牆 PersistentStore 與 ActiveStore，辨識本工具建立的規則。已建立者自動勾選，停用／PORT 不符／原則差異會顯示不同狀態。「取消選取」僅清空勾選，沒有全選按鈕；按「套用設定」才新增或更新勾選項目，並刪除原有勾選但此次取消的本工具規則。未按套用即關閉，不更動防火牆。

規則名稱例如 MSSQL 1433 (TCP)。使用固定內部 Name、專屬 Group 與 Description 標記辨識，不依賴歷史 LOG，也不僅以顯示名稱判斷；其他規則保留。同一內部 Name 若失去專屬標記，視為識別衝突，不修改、不刪除。未在本次初始狀態中的未勾選規則也不刪除。

LOG 下的 quickfirewall 執行目錄包含 before.json、firewall-result.json、report.json、report.html、run.log。規則符合只代表本機設定，不能保證應用程式正在監聽或外部網路可連線。

HRM（8044、8085）與 HRM 自有測試區（8046）另啟用本機 Windows 內建「分散式交易協調器」四條防火牆規則，套用私人、公用、網域；服務名稱及 PORT 欄維持不變。檢查同時核對 DTC 本機與有效規則；符合後狀態與滑鼠提示提醒 DB 主機也必須手動開啟「分散式交易協調器」。不更改 DTC 服務／安全性設定，也不遠端修改 DB 主機。取消 HRM 時只移除該項工具建立的 PORT 規則，保留共用 DTC；需要還原 DTC 請依 before.json 中 Dtc.Rules 的 Enabled、Action、Profile 手動調整。

## IIS 安裝方案

方案下拉選單位於「安裝 IIS」同一列；尚未安裝 IIS 時會提示按執行安裝，已安裝後切換方案會提示按執行補安裝缺少元件。切換方案不必先重新檢查狀態；「尚需設定」狀態以深灰色顯示。

依使用者提供的九張角色服務圖片設定，主程式目標仍為 .NET Framework 4.8。

| 方案 | 基本元件以外的項目 |
|---|---|
| 基本（預設） | 無 |
| ERP(WebDAV) | WebDAV 發行、基本驗證 |
| EFNET&CRM | Windows 驗證 |
| WebDAV+EFNET | WebDAV 發行、基本驗證、Windows 驗證 |

基本元件：HTTP 錯誤、預設文件、靜態內容、瀏覽目錄、要求篩選、HTTP 記錄、靜態內容壓縮、.NET 擴充性 3.5／4.x、ASP.NET 3.5／4.x、ISAPI 篩選器、ISAPI 擴充程式、IIS 管理主控台、IIS 6 Metabase 相容性、IIS 6 WMI 相容性。Windows 依需要加入父層與必要相依元件。

只安裝角色服務；不替網站設定 WebDAV 發行規則、驗證啟用狀態、帳號、站台或應用程式。已安裝的其他 IIS 元件保留；切換為較小方案不移除元件。

.NET 3.5 無相容光碟時，選「連網安裝」後才允許使用 Windows Update／系統設定的修復來源。若失敗、取消或需要重開機，IIS 不會接著安裝；其他工作繼續。IIS 本身使用 Windows 元件安裝，必要時可使用系統更新來源；勾選「僅使用離線檔案」則限制聯網。套用前備份元件狀態，套用後逐項核對。

變更方案後可按「僅檢查狀態」更新檢查結果，實際執行前也會重新檢查。

## 離線檔案

可按「停止後續作業」右側的「製作離線安裝包」，勾選並下載下列四個安裝檔；也可自行取得官方檔案，放在 EXE 旁的 Offline 資料夾：

| 功能 | 檔名 |
|---|---|
| 7-Zip x64 EXE | 7zip_installer.exe |
| 鼎新服務雲管家 | SCP.Desktop.Setup.exe |
| IIS Crypto CLI | IISCryptoCli.exe |
| Chrome x64 MSI | googlechromestandaloneenterprise64.msi |

勾選「僅使用離線檔案」可避免對工具下載來源發出請求；Windows 簽章信任檢查仍可能由作業系統查詢憑證狀態。離線備援與快取版本不會顯示成已確認最新版。

每個檔案執行前會重新核對 SHA-256、EXE 的 PE／MSI 產品資訊、簽章與預期發行者。已知檔案遭竄改、發行者不符或指定雜湊不符會拒絕。Chrome MSI 必須具有有效 Google 簽章、正確產品名稱與 x64 架構；其他工具無簽章或信任狀態不完整時可由操作員針對該檔案決定。SHA-256 必須與可信來源資料比較才具有來源驗證意義。

## 設定與資料位置

Config.json 可選，未放置時使用內建官方來源。可參照 Config.example.json 複製並改名。只接受 HTTPS；不能用設定檔指定腳本或任意命令。

執行資料：C:\伺服器設定工具（管理員啟動後自動建立）
- Cache：受 ACL 保護的外部工具。
- LOG\時間-識別碼：report.html、report.json、run.log、DISM 日誌及個別工作備份。
- TEMP：本工具使用的暫存、DISM 工作目錄；子程序 TEMP／TMP 指向此處。
- 語言偏好：C:\伺服器設定工具\language.txt。

舊版 %ProgramData%\ServerSetupTool 的歷史檔案不自動搬移或刪除。Windows 元件維護服務及第三方安裝器自行指定的日誌位置，仍由各元件決定；本工具不修改 Windows 全機暫存設定。

報告含原始系統訊息，該部分可能仍使用系統語言。未完成的報告會保留執行中狀態，重試前應重新掃描。備份留在伺服器。

## 備份與人工還原

每個設定工作修改前必須成功備份；失敗則不進行該設定。沒有整機一鍵回復功能。

- 防火牆：對照工作名稱-before.json，使用 Windows 防火牆管理工具恢復所列規則的 Enabled、Action、Profile、RemoteAddress；RDP 另含 LocalPort。
- RDP：同檔保存原始 Deny、NLA 及服務狀態；登錄值 null 表示原先不存在。依紀錄恢復，而非固定設為另一個值。
- UAC：uac-before.json 記錄原值與路徑。恢復 EnableLUA 後重新啟動。
- Chrome：預設不勾選；使用 Google 官方 x64 MSI 靜默安裝。偵測到電腦或使用者已安裝 Chrome 時直接略過，不重裝、不更新。
- .NET Framework 3.5：預設不勾選；先用相容光碟安裝，無相容光碟可選擇連網、指定 sxs 資料夾或取消。
- IIS：預設不勾選，方案預設「基本」。勾選時一併選取 .NET 3.5，必須完成 .NET 3.5 才安裝 IIS。需要重開機時先暫停 IIS，不自動重新開機。詳見下方方案表。
- 密碼複雜度：password-before.json 記錄原值，另保存 secedit 匯出 INF。還原時只套用原 PasswordComplexity，不將整份原則不加檢查地回灌。
- IIS Crypto：crypto-before.json 記錄相關路徑存在與否；crypto-before.reg 是官方備份。REG 匯入本身不會刪除套用後新增的值，需先比對 JSON／實際差異，確認後處理新增值，再重新啟動。
- 軟體安裝：使用產品自己的解除安裝／還原流程。
- Autologon：透過官方工具的 Disable 停用；本工具不讀取、備份或復原登入密碼。

若工作標示「可能已有變更／驗證未完成」，請檢視 before／after 及實際環境，不要假定沒有變更。

## 已知限制與驗證狀態

- 已完成編譯、純邏輯測試、Windows 11 唯讀掃描、三語字串驗證及 Windows Server 2025 自動化實測。實際介面操作待使用者驗收。
- Windows Server 2025 的防火牆、RDP、UAC、密碼原則、7-Zip、TLS 套用及重開機後設定已實測；詳見「自動化測試報告.md」。Server 2022、AD／GPO、互動安装與自動登入尚待實機驗收。
- v1.0.1 比對 IIS Crypto 4.0.18.0 的具體範本登錄值；設定符合不代表既有 TLS 連線已重新載入。未來範本變更需更新基準，詳見「更新說明-1.0.1.md」。
- 鼎新採互動安裝，識別使用已安裝程式資訊；廠商改名或特殊安裝方式可能需要人工驗證。
- GPO 能力是有限偵測：可讀取防火牆有效合併原則、RDP 原則及取得的結果原則；不能保證偵測所有 GPO／第三方管理軟體或未來覆蓋。
- 本機規則驗證不等於跨電腦連線測試；額外阻擋規則、網路設備及登入權限仍可能阻止連線。
- 「停止後續工作」不強制終止已開始的安裝或修改；若外部程序卡住，需人工處理。
- 程式目前未以商用程式碼簽章憑證簽署，UAC 可能顯示未知發行者；不影響 manifest 要求管理員權限。
- 外部安裝程式不隨本版 ZIP 再散布，執行時下載或由工程師提供。

## 原始碼建置與測試

使用現有 .NET SDK 建置，NuGet 自動還原 Microsoft.NETFramework.ReferenceAssemblies 1.0.3；無須在客戶端安裝此建置套件。

```text
dotnet build ServerSetupTool.csproj -c Release
ServerSetupTool.exe --self-test C:\\Temp\\self-tests.txt
ServerSetupTool.exe --inspect C:\\Temp\\inspection.json
ServerSetupTool.exe --integration-test C:\\Temp\\integration-tests.txt
```

原始碼 Scripts/Bridge.ps1 是嵌入 EXE 的固定實作資源，不作為使用者啟動入口；使用 Windows 內建 PowerShell 5.1 傳回結構化資料，不使用翻譯後的規則顯示名稱。

## 官方來源

- [7-Zip](https://www.7-zip.org/download.html)、[靜默安裝參數](https://www.7-zip.org/faq.html)
- [IIS Crypto](https://www.nartac.com/Products/IISCrypto/Download)
- [Microsoft Autologon](https://learn.microsoft.com/en-us/sysinternals/downloads/autologon)
- [鼎新安裝器](https://es-update.digiwin.com/installer/SCP/SCP.Desktop.Setup.exe)
- [Microsoft .NET Framework 參考組件](https://learn.microsoft.com/en-us/dotnet/framework/migration-guide/reference-assemblies)

## v1.0.2 下載與快取
官方未簽章 7-Zip x64 安裝檔不再顯示確認視窗。快取保留原始檔名，SHA-256 記錄於 JSON；舊快取在取用並驗證後改名。詳見「更新說明-1.0.2.md」。

## v1.0.3 光碟安裝 .NET Framework 3.5
（歷史版本行為；v1.0.6 已新增連網選擇）新增「快速安裝.NET Framework 3.5」，預設不勾選。自動辨識相符 Windows 安裝光碟的 sources\sxs，使用 DISM /LimitAccess /NoRestart 安裝，不使用 Windows Update、不自動重開機；無相符光碟就提示並停止該項。鼎新直接開啟安裝畫面，不再顯示前後的說明確認視窗。詳見「更新說明-1.0.3.md」。

## v1.0.4
新版改用 netplwiz 機碼設定並提供連結；移除來源位址區，新增進階防火牆與網卡設定按鈕。詳見「更新說明-1.0.4.md」。

## 查看工作說明

連點兩下工作名稱或一般狀態欄位，可查看白話的功能用途、目前檢查狀態、注意事項與下一步。防火牆項目另列出已檢查的規則數量與来源範圍摘要；本機設定符合不代表已從其他電腦成功連線。連結欄位仍開啟原本的 Windows 工具。說明視窗不修改設定，原始診斷資料保留在自動紀錄中。

## 使用手冊與離線準備

右上方「使用說明」會在瀏覽器開啟內嵌 HTML 手冊，提供章節目錄與搜尋。工作雙擊說明包含實際修改、備份檔與還原方向。勾選「僅使用離線檔案」後，清單依選取工作列出下載來源、固定檔名及 EXE 同層 Offline 的完整路徑；切換勾選後可再次點擊清單連結查看。

## SMB／UNC 直接執行

支援直接開啟 `\\IP\分享名稱\工具資料夾\ServerSetupTool.exe`，不需要 Z: 對應磁碟，也不會先將主 EXE 複製到本機。執行及修改的對象是啟動程式的那台 Windows。Config.json 與 Offline 讀取 EXE 同層內容；日誌、備份、TEMP 與 Cache 仍在執行機的 C:\伺服器設定工具。請維持 SMB 連線，並確保提升權限使用的帳號可讀取分享。

主畫面「執行所選項目」位於操作列最左側。表頭全選勾選框會先顯示不建議全選的提醒，確認後才選取可用項目；拒絕保留原勾選，已全選時再按可清空。五個工具按鈕（AD 自動登入連結、進階防火牆、快速防火牆、網卡設定、服務用本機帳號）在環境檢查期間即可開啟，各工具仍執行自身必要檢查。

## 製作離線安裝包（1.0.28）

在有網路的電腦按「製作離線安裝包」，勾選需要的 7-Zip、鼎新服務雲管家、IIS Crypto CLI 或 Chrome，再按「下載／準備勾選項目」。清單獨立於主畫面的工作選取，也可準備這台電腦已安裝或不適用、但目標電腦需要的工具。只下載與驗證，不執行安裝或套用系統設定。

目的地固定是執行中 EXE 同目錄的 Offline；不存在時自動建立。無法建立／寫入資料夾、連線失敗、逾時、磁碟空間不足、檔案占用與驗證失敗會在視窗顯示詳細錯誤及錯誤碼。下載與匯入在背景執行，可取消；取消後等待目前操作安全結束，保留已完成項目。個別下載失敗仍繼續其他勾選項目，結果分別列出成功與失敗，不將部分完成宣稱為全部成功。

同名安裝檔存在時會先詢問是否替換，預設為否；通過既有雜湊、格式、簽章與發行者檢查後才替換。新檔失敗不影響原檔，未完成的暫存檔會清理。製作功能不以舊快取或離線備援假裝下載成功。沒有自動保存舊版本安裝檔；若要保留，可先另行備份整個 Offline，還原時關閉程式後放回備份。

第五個選項是 .NET 3.5 的 Windows 安裝媒體匯入：請自行提供符合目標 Windows 版本、build 及 x64 架構的 sources/sxs，不是下載通用 .NET 安裝程式。匯入整個資料夾後保存在 Offline/sxs-時間-識別碼，不覆寫舊媒體。匯入只檢查來源中存在 NetFx3 CAB，不代表已通過目標機相容性驗證；實際安裝時仍由目標機檢查並由 DISM 驗證。IIS 可能另需相符的完整 Windows 安裝媒體，不能保證僅有 sxs 就能完成所有 IIS 元件。Windows 11 26H1 以上仍不支援本工具現有 NetFx3／IIS 元件流程。

製作完成後，將 ServerSetupTool.exe、ServerSetupTool.exe.config 與整個 Offline 一起複製到無法上網的電腦；有自訂 Config.json 時也一併帶走。目標電腦需先具備 .NET Framework 4.8。執行 EXE，勾選「僅使用離線檔案」，再勾選工作執行。需要 .NET 3.5 時，在來源視窗選擇複製過去的 Offline/sxs-* 資料夾。離線安裝仍保留原有簽章確認及安裝後驗證，不因製作完成就宣稱已安裝成功。
## GitHub 檢查更新（1.0.30）

正式發布來源為 https://github.com/digiwinserver-art/ServerSetupTool；公開內容只有發布用成品、使用說明與發布設定，不包含 C# 原始碼、私人設定或測試紀錄。

程式顯示主畫面後，獨立在背景查詢 GitHub 最新正式 Release。整體檢查以 2 秒為上限，不重試、不阻擋原本環境檢查，也不為離線、DNS／Proxy 問題、限流或未發布版本彈出錯誤。底層網路若未立即回應取消，逾時結果仍被丟棄，同時間最多保留一個檢查請求。找不到新版時可直接使用原版本。

主畫面標題右側顯示「檢查更新」，發現新版時附上版號。只有使用者點選提示並按「下載並準備新版」才下載；也可關閉視窗或稍後再說。平時可點「檢查更新」手動檢查。更新檢查及下載不會安裝軟體、套用伺服器設定或自動重開機。

新版以 ServerSetupTool-win-x64.zip 發布，必須由該儲存庫的正式 Release 提供 HTTPS 網址、大小及 GitHub SHA-256。程式只接受較新的 v主版.次版.修訂版，不使用草稿或預覽版。下載後核對大小與 SHA-256，檢查 ZIP 檔案清單、EXE 的 x64 格式與檔案／產品版本。缺少雜湊、非預期檔案、路徑穿越或版本不符均拒絕使用。此外，程式以內嵌公鑰驗證 release.json 與 release.json.sig 的 RSA-3072／SHA-256 簽章，核對簽署版本與雜湊；缺少或無效即拒絕，不退回僅驗 GitHub 雜湊。只接受內建官方儲存庫，不能由設定檔換成其他來源。這不是 Windows Authenticode 公司程式碼簽章。

使用者選擇存放位置後，程式建立獨立的 ServerSetupTool-版本 資料夾，不覆寫目前 EXE 或同名版本資料夾。將原本 Config.json、UpdateSettings.json 與整個 Offline 複製進新版；失敗或取消不修改原檔。Offline 很大時需要額外空間與複製時間，權限、磁碟、檔案占用等錯誤會顯示詳細訊息。ZIP 上限 128 MiB；下載上限 5 分鐘，可取消，設定與離線檔案複製亦可取消。

完成後按「開啟新版資料夾」，關閉目前程式，再執行新資料夾內的 ServerSetupTool.exe。日誌仍留在執行電腦的 C:\伺服器設定工具。需要回復時關閉新版，重新執行原 EXE；回復程式版本不會撤銷曾套用的 Windows 設定。將準備好的整個新版資料夾複製到離線電腦也可使用，目標電腦仍需 .NET Framework 4.8。

「啟動時自動檢查更新」可在檢查更新視窗取消，按「儲存設定並檢查」保存到 EXE 旁的 UpdateSettings.json；這次仍會依按鈕明示手動檢查，後續啟動不自動連線。也可依 UpdateSettings.example.json 預先設定 CheckOnStartup 為 false。檢查只使用公開 API，不儲存或要求 GitHub Token；私有儲存庫不支援。設定或網路問題不阻擋主程式。
## 紅色重新開機提醒（1.0.30）

只有本工具成功套用「完全停用 UAC」或「IIS Crypto」後，主畫面才顯示紅色「待重新啟動（點此重新開機）」。已符合而略過、執行失敗或其他 Windows 更新的待重開旗標不會觸發此提示。其他安裝工作自身的重開需求仍保留於結果與紀錄。

提示保存在本機，關閉再開程式仍會顯示，真正重新開機後清除。點紅字會先詢問，預設否；確認前請保存工作並通知其他使用者。Windows 以已計劃的「作業系統：重新設定」原因及 UAC／IIS Crypto 說明記錄重開機事件（系統記錄 USER32／1074）。不強制關閉應用程式；如 Windows 拒絕，顯示錯誤並保留提示。
